//
//  ViewController.m
//  OJT_DB
//
//  Created by Sangho Oh on 16/01/2019.
//  Copyright © 2019 Sangho Oh. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIButton *btnInsert;
@property (weak, nonatomic) IBOutlet UIButton *btnSelect;
@property (weak, nonatomic) IBOutlet UIButton *btnDelete;

@end

@implementation ViewController
NSString *dbPath;

// DB 연결 정보 객체 생성
sqlite3 *database;
// SQL 구문 컴파일러 객체 생성
sqlite3_stmt *databaseStatement = nil;
// SQL 구문
NSString *databaseQuery = nil;
// 오류 메시지 전달 받을 포인터 변수
char *dbError = nil;

- (void)viewDidLoad {
    [super viewDidLoad];
}

-(void)dbOpen {
    // dbPath 설정
    NSFileManager *fileMan = [NSFileManager defaultManager];
    NSURL *documentPathURL = [[fileMan URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask] lastObject];
    NSString *databaseFileName = @"test.sqlite";
    dbPath = [[documentPathURL URLByAppendingPathComponent: databaseFileName] path];
    
    // sqlite3_open >> dbPath의 파일이 있으면 open, 없으면 생성하고 open.
    if (sqlite3_open([dbPath UTF8String], &database) == SQLITE_OK) {
        NSLog(@"DB OPEN Success : %@" , dbPath);
    }
    else
    {
        NSLog(@"DB OPEN Fail");
    }
}

-(void)dbClose {
    // DB 닫기
    sqlite3_close(database);
    database = nil;
}

- (IBAction)btnInsert:(id)sender {
    
    // DB 열기
    [self dbOpen];
    
    // SQL 실행(sqlite3_exec) >> 반환 결과 없는 쿼리(CREATE, INSERT, UPDATE, DELETE 등)
    databaseQuery = @"CREATE TABLE IF NOT EXISTS 'Table1'('index' INTEGER PRIMARY KEY, 'value' TEXT);";
    if (sqlite3_exec(database, [databaseQuery UTF8String], NULL, NULL, &dbError) == SQLITE_OK) {
        NSLog(@"Create Success : %@" , databaseQuery);
    }
    else
    {
        NSLog(@"Create Fail");
    }
    
    databaseQuery = @"INSERT INTO 'Table1'('value') VALUES ('Sangho1');";
    if (sqlite3_exec(database, [databaseQuery UTF8String], NULL, NULL, &dbError) == SQLITE_OK) {
        NSLog(@"Insert Success : %@" , databaseQuery);
    }
    else
    {
        NSLog(@"Insert Fail");
    }
    // DB 닫기
    [self dbClose];
}

- (IBAction)btnSelect:(id)sender {
    // DB 열기
    [self dbOpen];
    
    NSString *field1Str, *field2Str;
    NSString *qsql = [NSString stringWithFormat:@"SELECT * FROM Table1"];
    sqlite3_stmt *statement;
    if (sqlite3_prepare_v2(database, [qsql UTF8String], -1, &statement, nil) == SQLITE_OK) {
        while (sqlite3_step(statement) == SQLITE_ROW) {
            char *field1 = (char *) sqlite3_column_text(statement, 0);
            char *field2 = (char *) sqlite3_column_text(statement, 1);
            
            field1Str = [[NSString alloc] initWithUTF8String:field1];
            field2Str = [[NSString alloc] initWithUTF8String:field2];
            
            NSString *str = [NSString stringWithFormat:@"%@ - %@", field1Str, field2Str];
            NSLog(@"%@", str);
        }
    }
    else
    {
        NSLog(@"Create Fail");
    }
    // DB 닫기
    [self dbClose];
}

- (IBAction)btnDelete:(id)sender {
    // DB 열기
    [self dbOpen];
    
    // SQL 실행(sqlite3_exec) >> 반환 결과 없는 쿼리(CREATE, INSERT, UPDATE, DELETE 등)
    databaseQuery = @"CREATE TABLE IF NOT EXISTS 'Table1'('index' INTEGER PRIMARY KEY, 'value' TEXT);";
    if (sqlite3_exec(database, [databaseQuery UTF8String], NULL, NULL, &dbError) == SQLITE_OK) {
        NSLog(@"Create Success : %@" , databaseQuery);
    }
    else
    {
        NSLog(@"Create Fail");
    }
    // DB 닫기
    [self dbClose];
}

- (IBAction)btnUpdate:(id)sender {
    // DB 열기
    [self dbOpen];
    
    // SQL 실행(sqlite3_exec) >> 반환 결과 없는 쿼리(CREATE, INSERT, UPDATE, DELETE 등)
    //databaseQuery = @"INSERT INTO 'Table1'('value') VALUES ('Hello, World!');";
    databaseQuery = @"UPDATE Table1 SET value='Sangho10' WHERE index='Sangho2';";
    if (sqlite3_prepare_v2(database, [databaseQuery UTF8String], -1, &databaseStatement, nil) == SQLITE_OK) {
        NSLog(@"Update Success : %@" , databaseQuery);
    }
    else
    {
        NSLog(@"Update Fail");
    }
    // DB 닫기
    [self dbClose];
}

@end
