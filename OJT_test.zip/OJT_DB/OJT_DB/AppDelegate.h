//
//  AppDelegate.h
//  OJT_DB
//
//  Created by Sangho Oh on 16/01/2019.
//  Copyright © 2019 Sangho Oh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (readonly, strong) NSPersistentContainer *persistentContainer;

- (void)saveContext;


@end

