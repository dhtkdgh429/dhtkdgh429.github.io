//
//  ViewController.m
//  WKWebView_test
//
//  Created by Sangho Oh on 18/01/2019.
//  Copyright © 2019 Sangho Oh. All rights reserved.
//

#import "ViewController.h"
#define my_URL @"https://dhtkdgh429.github.io"

@interface ViewController ()

@end

@implementation ViewController



- (void)viewDidLoad {
    [super viewDidLoad];
    [self webConfig];
}

-(void)webConfig {
    WKWebViewConfiguration *webConfig = [[WKWebViewConfiguration alloc] init];
    WKUserContentController *controller = [[WKUserContentController alloc] init];
    
    [controller addScriptMessageHandler: self name:@"saveImageHandler"];
    webConfig.userContentController = controller;
    
    _webView = [[WKWebView alloc] initWithFrame:self.view.frame configuration:webConfig];
    
    [_webView loadRequest: [NSURLRequest requestWithURL: [NSURL URLWithString: my_URL]]];
    [self.view addSubview: _webView];
}

-(void)userContentController:(WKUserContentController *)userContentController didReceiveScriptMessage:(WKScriptMessage *)message {
    NSLog(@"name : %@, body : %@", message.name, message.body);
    if ([message.name hasPrefix: @"saveImageHandler"]) {
        
        NSArray *arrMsg = [message.body componentsSeparatedByString: @"::"];
        
        NSString *imgName = [arrMsg objectAtIndex: 0];
        NSString *imgDesc = [arrMsg objectAtIndex: 1];
        NSString *imgUrl = [arrMsg objectAtIndex: 2];
        
        NSLog(@"img log : %@, %@, %@", imgName, imgDesc, imgUrl);
        
    }
        
}


@end
