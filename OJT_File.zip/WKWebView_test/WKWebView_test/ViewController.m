//
//  ViewController.m
//  WKWebView_test
//
//  Created by Sangho Oh on 18/01/2019.
//  Copyright © 2019 Sangho Oh. All rights reserved.
//

#import "ViewController.h"
#define my_URL @"https://dhtkdgh429.github.io"

@interface ViewController ()

@end

@implementation ViewController

NSString *dbPath;

// DB 연결 정보 객체 생성
sqlite3 *database;
// SQL 구문
NSString *databaseQuery = nil;
// 오류 메시지 전달 받을 포인터 변수
//char *dbError = nil;

- (void)viewDidLoad {
    [super viewDidLoad];
    [self webConfig];
}

-(void)webConfig {
    WKWebViewConfiguration *webConfig = [[WKWebViewConfiguration alloc] init];
    WKUserContentController *controller = [[WKUserContentController alloc] init];
    
    [controller addScriptMessageHandler: self name:@"saveImageHandler"];
    webConfig.userContentController = controller;
    
    _webView = [[WKWebView alloc] initWithFrame:self.view.frame configuration:webConfig];
    
    [_webView loadRequest: [NSURLRequest requestWithURL: [NSURL URLWithString: my_URL]]];
    [self.view addSubview: _webView];
}

-(void)userContentController:(WKUserContentController *)userContentController didReceiveScriptMessage:(WKScriptMessage *)message {
    NSLog(@"name : %@, body : %@", message.name, message.body);
    if ([message.name hasPrefix: @"saveImageHandler"]) {
        
        NSArray *arrMsg = [message.body componentsSeparatedByString: @"::"];
        
        NSString *imgName = [arrMsg objectAtIndex: 0];
        NSString *imgDesc = [arrMsg objectAtIndex: 1];
        NSString *imgUrl = [arrMsg objectAtIndex: 2];
        
        NSLog(@"img log : %@, %@, %@", imgName, imgDesc, imgUrl);
        
        [self dbInsertDataWithName:imgName desc:imgDesc url:imgUrl];
        [self dbSelectData];
    }
}

-(void)dbOpen {
    // dbPath 설정
    NSFileManager *fileMan = [NSFileManager defaultManager];
    NSURL *documentPathURL = [[fileMan URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask] lastObject];
    NSString *databaseFileName = @"test.sqlite";
    dbPath = [[documentPathURL URLByAppendingPathComponent: databaseFileName] path];
    
    // sqlite3_open >> dbPath의 파일이 있으면 open, 없으면 생성하고 open.
    if (sqlite3_open([dbPath UTF8String], &database) == SQLITE_OK) {
        NSLog(@"DB OPEN Success : %@" , dbPath);
    }
    else
    {
        NSLog(@"DB OPEN Fail");
    }
}

-(void)dbClose {
    
    // DB 닫기
    sqlite3_close(database);
    database = nil;
}

-(void)dbInsertDataWithName:(NSString *)name desc:(NSString *)desc url:(NSString *)url {
    
    // DB 열기
    [self dbOpen];
    
    // name, desc, url 중 하나라도 빈칸이 있을 경우, insert하지 않고 pass.
    if (![name isEqualToString:@""] && ![desc isEqualToString:@""] && ![url isEqualToString:@""]) {
        
        // SQL 실행(sqlite3_exec) >> 반환 결과 없는 쿼리(CREATE, INSERT, UPDATE, DELETE 등)
        databaseQuery = @"CREATE TABLE IF NOT EXISTS 'Table1'('index' INTEGER PRIMARY KEY, 'name' TEXT, 'desc' TEXT, 'url' TEXT);";
        if (sqlite3_exec(database, [databaseQuery UTF8String], NULL, NULL, nil) == SQLITE_OK) {
            NSLog(@"Create Success : %@" , databaseQuery);
        }
        else
        {
            NSLog(@"Create Fail");
        }
        databaseQuery = @"INSERT INTO Table1 (name, desc, url) VALUES (?, ?, ?)";
        //    databaseQuery = @"UPDATE Table1 SET name=? WHERE name IS NULL";
        sqlite3_stmt *statement;
        
        if (sqlite3_prepare_v2(database, [databaseQuery UTF8String], -1, &statement, nil) == SQLITE_OK) {
            sqlite3_bind_text(statement, 1, [name UTF8String], -1, SQLITE_TRANSIENT);
            sqlite3_bind_text(statement, 2, [desc UTF8String], -1, nil);
            sqlite3_bind_text(statement, 3, [url UTF8String], -1, nil);
            
            NSLog(@"Insert Success : %@" , databaseQuery);
        }
        else
        {
            NSLog(@"Insert Fail");
        }
        // 질의 종료
        sqlite3_step(statement);
        sqlite3_finalize(statement);
    }
    // DB 닫기
    [self dbClose];
}

-(void)dbSelectData {
    // DB 열기
    [self dbOpen];
    
//    NSString *field1Str, *field2Str, *field3Str;
    NSString *qsql = [NSString stringWithFormat:@"SELECT * FROM Table1"];
    sqlite3_stmt *statement;
    if (sqlite3_prepare_v2(database, [qsql UTF8String], -1, &statement, nil) == SQLITE_OK) {
        while (sqlite3_step(statement) == SQLITE_ROW) {
            NSString *strField1 = [[NSString alloc] initWithUTF8String:(char *)sqlite3_column_text(statement, 1)];
            NSString *strField2 = [[NSString alloc] initWithUTF8String:(char *)sqlite3_column_text(statement, 2)];
            NSString *strField3 = [[NSString alloc] initWithUTF8String:(char *)sqlite3_column_text(statement, 3)];
            
//            char *field1 = (char *) sqlite3_column_text(statement, 1);
//            char *field2 = (char *) sqlite3_column_text(statement, 2);
//            char *field3 = (char *) sqlite3_column_text(statement, 3);
//
//            field1Str = [[NSString alloc] initWithUTF8String:field1];
//            field2Str = [[NSString alloc] initWithUTF8String:field2];
//            field3Str = [[NSString alloc] initWithUTF8String:field3];
            
//            NSString *str = [NSString stringWithFormat:@"%@ - %@ - %@", field1Str, field2Str, field3Str];
            NSString *str = [NSString stringWithFormat:@"%@ - %@ - %@", strField1, strField2, strField3];
            NSLog(@"%@", str);
            
            // 여기서 tableview로 데이터 바인딩 해주는 작업 필요할 듯.
        }
    }
    else
    {
        NSLog(@"Select Fail");
    }
    // 질의 종료
//    sqlite3_step(statement);
    sqlite3_finalize(statement);
    // DB 닫기
    [self dbClose];
}


@end
