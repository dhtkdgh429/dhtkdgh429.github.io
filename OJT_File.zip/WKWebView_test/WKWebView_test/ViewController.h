//
//  ViewController.h
//  WKWebView_test
//
//  Created by Sangho Oh on 18/01/2019.
//  Copyright © 2019 Sangho Oh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>
#import <sqlite3.h>

@interface ViewController : UIViewController <WKScriptMessageHandler>

@property(strong, nonatomic) WKWebView *webView;

@end

