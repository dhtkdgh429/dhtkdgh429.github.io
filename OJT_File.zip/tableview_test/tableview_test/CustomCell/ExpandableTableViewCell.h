//
//  ExpandableTableViewCell.h
//  tableview_test
//
//  Created by Oh Sangho on 20/01/2019.
//  Copyright © 2019 Oh Sangho. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ExpandableTableViewCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UILabel *rowCount;

@property (strong, nonatomic) IBOutlet UILabel *rowName;

@property (strong, nonatomic) IBOutlet UILabel *fruitName;

@property (strong, nonatomic) IBOutlet UILabel *fruitValue;

@property (weak, nonatomic) IBOutlet UIButton *buttonAction;

@end
