//
//  ExpandableTableViewCell.m
//  tableview_test
//
//  Created by Oh Sangho on 20/01/2019.
//  Copyright © 2019 Oh Sangho. All rights reserved.
//

#import "ExpandableTableViewCell.h"

@implementation ExpandableTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
