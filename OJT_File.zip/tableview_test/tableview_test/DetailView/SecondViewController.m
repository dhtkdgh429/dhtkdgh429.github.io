//
//  SecondViewController.m
//  tableview_test
//
//  Created by Oh Sangho on 20/01/2019.
//  Copyright © 2019 Oh Sangho. All rights reserved.
//

#import "SecondViewController.h"

@interface SecondViewController ()

@end

@implementation SecondViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}
- (void)viewWillAppear:(BOOL)animated {
    if (_isFruitName == 1) {
        _arrFruit = [[NSMutableArray alloc] initWithObjects:@"Apple", @"Mango", @"Banana", @"Cherry", nil];
        _selectedFruit.text = [_arrFruit objectAtIndex:_SelectedRowValue];
    }
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
