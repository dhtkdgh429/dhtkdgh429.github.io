//
//  ViewController.m
//  tableview_test
//
//  Created by Oh Sangho on 20/01/2019.
//  Copyright © 2019 Oh Sangho. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    
    _selectedIndex = -1;
    
    _arrayTitle = [[NSMutableArray alloc] init];
    
    for (int ii = 0; ii <= 3; ii++) {
        NSString *name = [[NSString alloc] initWithFormat:@"Row %i", ii];
        
        [_arrayTitle addObject:name];
    }
    
    _arraySecond = [[NSMutableArray alloc] initWithObjects:@"Row Apple", @"Row Mango", @"Row Banana", @"Row Cherry", nil];
    _arrayName = [[NSMutableArray alloc] initWithObjects:@"Apple", @"Mango", @"Banana", @"Cherry", nil];
    
    
    _customTableView.delegate = self;
    _customTableView.dataSource = self;
}

-(void) buttonImageName {
    // 여기서부터 확인 필요. >> secondView(detailView) 불러오는 부분. 어떻게 불러올지 다시 찾아보자.
    //SecondViewController *secondVC = [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"SecondViewController"];
    SecondViewController *secondVC = [[NSBundle mainBundle] loadNibNamed:@"SecondViewController" owner:self options:nil];
    secondVC.SelectedRowValue = _buttonFruitName.tag;
    secondVC.isFruitName = 1;
    [self.navigationController pushViewController:secondVC animated:true];
}

// TableVIew

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _arrayTitle.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    ExpandableTableViewCell *cell = (ExpandableTableViewCell *)[_customTableView dequeueReusableCellWithIdentifier:@"cell"];
    if (cell == nil) {
        // Expandable.xib load
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"Expandable" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    cell.rowCount.text = [_arrayTitle objectAtIndex:indexPath.row];
    cell.rowName.text = [_arraySecond objectAtIndex:indexPath.row];
    cell.fruitName.text = [_arrayName objectAtIndex:indexPath.row];
    int fruitCount = (indexPath.row + 1) * 15;
    cell.fruitValue.text = [NSString stringWithFormat:@"%i", fruitCount];
    
    // 버튼 tag 가져오기
    _buttonFruitName = cell.buttonAction;
    _buttonFruitName.tag = indexPath.row;
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 100;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (_selectedIndex == indexPath.row) {
        _selectedIndex = -1;
        [_customTableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
        return;
    }
    
    if (_selectedIndex == -1) {
        NSIndexPath *previous = [NSIndexPath indexPathForRow:_selectedIndex inSection:0];
        _selectedIndex = indexPath.row;
        [_customTableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:previous] withRowAnimation:UITableViewRowAnimationFade];
    }
    _selectedIndex = indexPath.row;
    [_customTableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    [_buttonFruitName addTarget:self action:@selector(buttonImageName) forControlEvents:UIControlEventTouchDown];
}

@end
